import aiohttp
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from dotenv import load_dotenv
import os
from urllib.parse import quote
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Загружаем переменные окружения
load_dotenv()
API_TOKEN = os.getenv("API_TOKEN")
FASTAPI_URL = os.getenv("FASTAPI_URL", "http://fastapi_container:8000")
bot = Bot(token=API_TOKEN)
dp = Dispatcher()

# Определяем состояния FSM
class UserStates(StatesGroup):
    CHOOSING_MODE = State()          # Состояние выбора режима
    ASKING_AI = State()             # Состояние общения с нейросетью
    USING_MANUAL_LISTING = State()  # Состояние просмотра списка тем
    USING_MANUAL_VIEWING = State()  # Состояние просмотра информации о теме

# Обработчик команды /start
@dp.message(Command("start"))
async def start_command(message: Message, state: FSMContext):
    await message.answer("Привет! Выберите действие:\n1. Обратиться к нейросети\n2. Обратиться к справочнику")
    await state.set_state(UserStates.CHOOSING_MODE)

# Обработчик выбора режима
@dp.message(UserStates.CHOOSING_MODE)
async def choose_mode(message: Message, state: FSMContext):
    if message.text == "1":
        await state.set_state(UserStates.ASKING_AI)
        await message.answer("Вы выбрали обращение к нейросети. Задайте ваш вопрос.\n\nЧтобы вернуться в меню, введите /menu")
    elif message.text == "2":
        await state.set_state(UserStates.USING_MANUAL_LISTING)
        topics = await get_topics_from_neo4j()
        valid_topics = [topic for topic in topics if isinstance(topic, str) and topic]
        if valid_topics:
            topics_list = "\n".join(valid_topics)
            await message.answer(
                f"Вы выбрали справочник. Доступные темы:\n{topics_list}\n"
                "Выберите тему, введя её название, или введите 'назад' для возврата.\n\n"
                "Чтобы вернуться в меню, введите /menu"
            )
        else:
            logger.warning(f"Нет валидных тем: {topics}")
            await message.answer(
                "Справочник пуст или данные недоступны. Пожалуйста, попробуйте позже.\n\n"
                "Чтобы вернуться в меню, введите /menu"
            )
    else:
        await message.answer("Пожалуйста, выберите 1 или 2.")

# Обработчик вопросов к нейросети
@dp.message(UserStates.ASKING_AI)
async def handle_ai_question(message: Message, state: FSMContext):
    if message.text.lower() == "/menu":
        await menu_command(message, state)
        return
    payload = {"user_id": message.from_user.id, "question": message.text}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{FASTAPI_URL}/answer_question/", json=payload) as response:
                if response.status == 200:
                    response_data = await response.json()
                    answer = response_data.get("answer", "Нет ответа от сервера.")
                    await message.answer(f"{answer}\n\nЧтобы вернуться в меню, введите /menu")
                else:
                    logger.error(f"Ошибка FastAPI: статус {response.status}")
                    await message.answer(f"Ошибка на стороне сервера FastAPI.\n\nЧтобы вернуться в меню, введите /menu")
    except Exception as e:
        logger.error(f"Ошибка при запросе к FastAPI: {e}")
        await message.answer(f"Произошла ошибка: {e}\n\nЧтобы вернуться в меню, введите /menu")

# Обработчик списка тем в справочнике
@dp.message(UserStates.USING_MANUAL_LISTING)
async def handle_manual_listing(message: Message, state: FSMContext):
    if message.text.lower() == "/menu":
        await menu_command(message, state)
        return
    if message.text.lower() == "назад":
        await state.set_state(UserStates.CHOOSING_MODE)
        await message.answer("Выберите действие:\n1. Обратиться к нейросети\n2. Обратиться к справочнику")
    else:
        topic = message.text
        topic_data = await get_topic_data_from_neo4j(topic)
        if topic_data:
            description = topic_data.get("description", "Описание не найдено.")
            links = topic_data.get("links", [])
            links_str = "\n".join(links) if links else "Ссылки не найдены."
            await message.answer(
                f"Тема: {topic}\nОписание: {description}\nСсылки:\n{links_str}\n\n"
                "Введите 'назад' для возврата к списку тем.\n"
                "Чтобы вернуться в меню, введите /menu"
            )
            await state.set_state(UserStates.USING_MANUAL_VIEWING)
        else:
            topics = await get_topics_from_neo4j()
            valid_topics = [topic for topic in topics if isinstance(topic, str) and topic]
            if valid_topics:
                topics_list = "\n".join(valid_topics)
                await message.answer(
                    f"Тема не найдена. Пожалуйста, выберите из списка.\n"
                    f"Доступные темы:\n{topics_list}\n\n"
                    "Чтобы вернуться в меню, введите /menu"
                )
            else:
                logger.warning(f"Нет валидных тем: {topics}")
                await message.answer(
                    "Справочник пуст или данные недоступны.\n\nЧтобы вернуться в меню, введите /menu"
                )

# Обработчик просмотра темы
@dp.message(UserStates.USING_MANUAL_VIEWING)
async def handle_manual_viewing(message: Message, state: FSMContext):
    if message.text.lower() == "/menu":
        await menu_command(message, state)
        return
    if message.text.lower() == "назад":
        await state.set_state(UserStates.USING_MANUAL_LISTING)
        topics = await get_topics_from_neo4j()
        valid_topics = [topic for topic in topics if isinstance(topic, str) and topic]
        if valid_topics:
            topics_list = "\n".join(valid_topics)
            await message.answer(
                f"Доступные темы:\n{topics_list}\n"
                "Выберите тему, введя её название, или введите 'назад' для возврата.\n\n"
                "Чтобы вернуться в меню, введите /menu"
            )
        else:
            logger.warning(f"Нет валидных тем: {topics}")
            await message.answer(
                "Справочник пуст или данные недоступны.\n\nЧтобы вернуться в меню, введите /menu"
            )
    else:
        await message.answer(
            "Пожалуйста, введите 'назад' для возврата к списку тем.\n\n"
            "Чтобы вернуться в меню, введите /menu"
        )

# Обработчик команды /menu для возврата к выбору режима
@dp.message(Command("menu"))
async def menu_command(message: Message, state: FSMContext):
    await state.set_state(UserStates.CHOOSING_MODE)
    await message.answer("Выберите действие:\n1. Обратиться к нейросети\n2. Обратиться к справочнику")

# Функция для получения списка тем из Neo4j через FastAPI
async def get_topics_from_neo4j():
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{FASTAPI_URL}/get_topics/") as response:
                if response.status == 200:
                    data = await response.json()
                    topics = data.get("topics", [])
                    logger.info(f"Получены темы: {topics}")
                    return topics
                else:
                    logger.error(f"Ошибка при запросе тем: статус {response.status}")
                    return []
    except Exception as e:
        logger.error(f"Ошибка при запросе к /get_topics/: {e}")
        return []

# Функция для получения данных о теме из Neo4j через FastAPI
async def get_topic_data_from_neo4j(topic_name):
    try:
        encoded_name = quote(topic_name)
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{FASTAPI_URL}/get_topic/{encoded_name}") as response:
                if response.status == 200:
                    data = await response.json()
                    if "error" in data:
                        logger.warning(f"Тема не найдена: {topic_name}")
                        return None
                    logger.info(f"Получены данные темы {topic_name}: {data}")
                    return data
                else:
                    logger.error(f"Ошибка при запросе темы {topic_name}: статус {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Ошибка при запросе к /get_topic/{topic_name}: {e}")
        return None

# Запуск бота
async def main():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())