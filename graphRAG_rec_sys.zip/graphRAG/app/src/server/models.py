from pydantic import BaseModel

class QuestionRequest(BaseModel):
    user_id: int
    question: str
