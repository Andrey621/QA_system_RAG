import os
from fastapi import FastAPI, File, UploadFile
from neo4j import GraphDatabase
from langchain_neo4j import Neo4jGraph
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_experimental.graph_transformers import LLMGraphTransformer
from langchain_community.vectorstores import Neo4jVector
from langchain.chains import RetrievalQA
from langchain_ollama import OllamaLLM
from langchain_text_splitters import TokenTextSplitter
from models import QuestionRequest
from langchain.document_loaders import PyPDFLoader
from dotenv import load_dotenv
from huggingface_hub import snapshot_download
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Путь к папке с моделями
models_dir = "/app/models"
model_path = os.path.join(models_dir, "BAAI/bge-base-en-v1.5")

# Проверяем и загружаем модель, если нужно
if not os.path.exists(models_dir) or not os.listdir(models_dir):
    logger.info("Папка models пуста или отсутствует. Загрузка модели BAAI/bge-base-en-v1.5...")
    os.makedirs(models_dir, exist_ok=True)
    snapshot_download(repo_id="BAAI/bge-base-en-v1.5", local_dir=model_path)
    logger.info("Модель успешно загружена.")
else:
    logger.info("Папка models не пуста. Пропускаем загрузку модели.")

# Инициализация эмбеддингов
try:
    embeddings = HuggingFaceEmbeddings(model_name=model_path)
    logger.info("Модель успешно загружена в HuggingFaceEmbeddings.")
except Exception as e:
    logger.error(f"Ошибка при загрузке модели: {e}")

# Загрузка переменных окружения
load_dotenv()
NEO4J_URI = os.getenv("NEO4J_URI", "neo4j://neo4j_container:7687")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

app = FastAPI()

# Подключение к Neo4j
try:
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
    driver.verify_connectivity()
    graph = Neo4jGraph(
        url=NEO4J_URI,
        username=NEO4J_USERNAME,
        password=NEO4J_PASSWORD
    )
    logger.info("Neo4j connection successful!")
except Exception as e:
    logger.error(f"Neo4j connection failed: {e}")
    raise ValueError("Could not connect to Neo4j database. Please check the connection settings.")

# Инициализация LLaMA
llm = OllamaLLM(
    model="llama3:8b",
    base_url="http://ollama_container:11434",
    system="Ты работаешь с текстом на русском языке. Ты должен извлекать сущности и связи между ними, а также отвечать на вопросы на русском языке."
)

@app.get("/health")
def health_check():
    return {"status": "ok"}

# Обработка вопросов к нейросети
@app.post("/answer_question/")
async def answer_question(data: QuestionRequest):
    vector_index = Neo4jVector.from_existing_graph(
        embeddings,
        url=NEO4J_URI,
        username=NEO4J_USERNAME,
        password=NEO4J_PASSWORD,
        search_type="hybrid",
        node_label=["Document", "Entity", "Concept"],
        text_node_properties=["text"],
        embedding_node_property="embedding"
    )

    qa_chain = RetrievalQA.from_chain_type(
        llm, retriever=vector_index.as_retriever()
    )

    try:
        query = f"Ответь на русском языке: {data.question}"
        result = qa_chain({"query": query})
        answer = result["result"]
    except Exception as e:
        logger.error(f"Ошибка при обработке вопроса: {e}")
        answer = f"Ошибка при обработке вопроса: {str(e)}"

    return {"answer": answer}

# Получение списка тем
@app.get("/get_topics/")
async def get_topics():
    try:
        with driver.session() as session:
            result = session.run("MATCH (t:Topic) WHERE t.name IS NOT NULL RETURN t.name AS name")
            topics = [record["name"] for record in result if record["name"] is not None]
            if not topics:
                logger.info("Нет тем с непустыми именами в базе данных")
            else:
                logger.info(f"Возвращены темы: {topics}")
            return {"topics": topics}
    except Exception as e:
        logger.error(f"Ошибка при получении тем: {e}")
        return {"error": str(e)}

# Получение данных о конкретной теме
@app.get("/get_topic/{topic_name}")
async def get_topic(topic_name: str):
    try:
        with driver.session() as session:
            result = session.run(
                "MATCH (t:Topic {name: $name}) RETURN t.description AS description, t.links AS links",
                name=topic_name
            )
            record = result.single()
            if record:
                description = record["description"] if record["description"] else "Описание не найдено"
                links = record["links"] if record["links"] else []
                logger.info(f"Тема найдена: {topic_name}")
                return {"description": description, "links": links}
            else:
                logger.warning(f"Тема не найдена: {topic_name}")
                return {"error": "Тема не найдена"}
    except Exception as e:
        logger.error(f"Ошибка при получении темы {topic_name}: {e}")
        return {"error": str(e)}

# Обработка PDF
@app.post("/process_pdf/")
async def kg_builder(pdf_file: UploadFile = File(...)):
    temp_pdf_path = "temp_uploaded_file.pdf"
    with open(temp_pdf_path, "wb") as f:
        f.write(await pdf_file.read())

    loader = PyPDFLoader(temp_pdf_path)
    documents = loader.load()

    text_splitter = TokenTextSplitter(chunk_size=512, chunk_overlap=24)
    documents = text_splitter.split_documents(documents)

    llm_transformer = LLMGraphTransformer(llm=llm)
    graph_documents = llm_transformer.convert_to_graph_documents(documents)

    graph.add_graph_documents(
        graph_documents,
        baseEntityLabel=True,
        include_source=True
    )

    os.remove(temp_pdf_path)

    return {"message": "PDF обработан и граф загружен в Neo4j"}